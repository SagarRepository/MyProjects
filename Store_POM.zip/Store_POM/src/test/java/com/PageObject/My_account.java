package com.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class My_account {

	// create object of webdriver
	WebDriver ldriver;

	// constructor
	public My_account(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// Identify webElements
	@FindBy(id = "email_create")
	WebElement emailAdd;

	@FindBy(id = "SubmitCreate")
	WebElement submitemail;

	// Identify the action on webElement
	public void createEmail(String addEmail) {
		emailAdd.sendKeys(addEmail);
	}

	public void clk_Submit() {
		submitemail.click();
	}
}
