package com.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class accountCreationDetails {
	
WebDriver ldriver;
	
	public accountCreationDetails(WebDriver rdriver)
	{
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(id ="id_gender1")
	WebElement checkbox_Mr;
	
	@FindBy(xpath ="//input[@id='customer_firstname']")
	WebElement firstName;
	
	@FindBy(xpath ="//input[@id='customer_lastname']")
	WebElement lastName;
	
	@FindBy(id="email")
	WebElement enterEmail;
	
	@FindBy(id="passwd")
	WebElement pwd;
	
	// your address
	@FindBy(id="firstname")
	WebElement addfirstName;
	
	@FindBy(id="lastname")
	WebElement addlastName;
	
	@FindBy(id="company")
	WebElement addCompany;
	
	@FindBy(id ="address1")
	WebElement address;
	
	@FindBy(id ="city")
	WebElement addcity;
	
	//state
	@FindBy(id="id_state")
	WebElement state;
	
	@FindBy(id="postcode")
	WebElement zipCode;
	
	//country
	@FindBy(id ="id_country")
	WebElement country;
	
	//additional info
	@FindBy(id="other")
	WebElement addInfo;
	
	@FindBy(id="phone_mobile")
	WebElement phoneNo;
	
	@FindBy(id="alias")
	WebElement refEmail;
	
	@FindBy(id ="submitAccount")
	WebElement register;
	
	// identify action to be perform on webElement
	
	public void selectTitle() 
	{
		checkbox_Mr.click();
	}
	
	public void custFirstName(String fname)
	{
		firstName.sendKeys(fname);
	}
	
	public void custLastName(String lname)
	{
		lastName.sendKeys(lname);
	}
	
	public void enterPass(String pass)
	{
		pwd.sendKeys(pass);
	}
	
	public void enterAddFirstName(String first)
	{
		addfirstName.clear();
		addfirstName.sendKeys(first);;
	}
	
	public void enterAddLastName(String last)
	{
		addlastName.clear();
		addlastName.sendKeys(last);;
	}
	
	public void enterAddress(String add)
	{
		address.sendKeys(add);;
	}
	
	public void entercity(String cty)
	{
		addcity.sendKeys(cty);
	}
	
	// state dropdown
	public void selectState(String text)
	{
		Select sel = new Select(state);
		sel.selectByVisibleText(text);
	}
	
	public void enterPostCode(String postal)
	{
		zipCode.sendKeys(postal);;
	}
	
	public void selectCountry(String text)
	{
		Select sel_1 = new Select(country);
		sel_1.selectByVisibleText(text);
	}
	
	public void enterAdditionalInfo(String info)
	{
		addInfo.sendKeys(info);
	}
	
	public void enterMobile(String mobile)
	{
		phoneNo.sendKeys(mobile);
	}
	
	public void enterAlias(String alias)
	{
		refEmail.clear();
		refEmail.sendKeys(alias);
	}
	
	public void clkOnResister()
	{
		register.click();
	}
	
	
}

