package com.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class IndexPage {
	
	// create object of webdriver
	WebDriver ldriver;
	
	// create parameterised constructor
	public IndexPage(WebDriver rdriver)
	{
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	// Identify webElements
	@FindBy(linkText = "Sign in")
	WebElement signIn;
	
	// Identify the action on webElement
	public void clkOnSignIn()
	{
		signIn.click();
	}
	
	
	

}
