package com.PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ResisterUserAccount {
WebDriver ldriver;
	
	public ResisterUserAccount(WebDriver rdriver)
	{
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	// identify webElement
	@FindBy(xpath = "//a[@title='View my customer account']")
	WebElement username;
	
	public String getUsername()
	{
		String text = username.getText();	
		return text;
	}
	

}
