package com.Utility;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadConfig {

	// create a object of properties class
	Properties properties;
	String path = "D:\\ Program\\Store_POM\\Configuration\\config.properties";

	// create constructor
	public ReadConfig() {
		properties = new Properties();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			properties.load(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch blocsk
			e.printStackTrace();
		}
	}

	public String getBaseUrl() {
		String value = properties.getProperty("baseUrl");
		if (value != null)
			return value;
		else
			throw new RuntimeException("Url not specified in config file");

	}
	
	public String getBrowser() {
		String value = properties.getProperty("browser");
		if (value != null)
			return value;
		else
			throw new RuntimeException("browser name not specified in config file");
}
	
}
