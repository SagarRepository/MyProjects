package com.TestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.PageObject.IndexPage;
import com.PageObject.My_account;
import com.PageObject.ResisterUserAccount;
import com.PageObject.accountCreationDetails;

public class TC_MyAccoutPageTest extends Baseclass {
	
	@Test
	public void verifyResistration_and_login()
	{
		//open url
		driver.get(url);
		logger.info("url opend");
		
		// IndexPage - 1st page - create object of Index page class to access method
		IndexPage pg = new IndexPage(driver);
		pg.clkOnSignIn();
		logger.info("click on sign in");
		
		// My_account - 2nd page - create object of myAccount page
		My_account ac = new My_account(driver);
		ac.createEmail("sagu151121@gmail.com");
		logger.info("Enter email address");
		ac.clk_Submit();
		logger.info("click on submit");
		
		// create obje of accountcreation class
		accountCreationDetails details = new accountCreationDetails(driver);
		details.selectTitle();
		logger.info("Select gender in checkox");
		
		details.custFirstName("Sagu");
		logger.info("Enter cust first name");
		
		details.custLastName("pran");
		logger.info("Enter cust last name");
		
		details.enterPass("Sagu@12");
		logger.info("Enter password");
		
		details.enterAddFirstName("abc");
		logger.info("Enter first name of address");
		
		details.enterAddLastName("xyz");
		logger.info("Enter last name of address");
		
		details.enterAddress("OMNagar");
		logger.info("Enter address");
		
		details.entercity("yavatmal");
		logger.info("Enter city");
		
		details.selectState("Alabama");
		logger.info("Select state from dropdown");
		
		details.enterPostCode("53290");
		logger.info("enter postal code");
		
		details.selectCountry("United States");
		logger.info("Select country from dropdown");
		
		details.enterAdditionalInfo("7709977099");
		logger.info("Add description in box");
		
		details.enterMobile("7863149123");
		logger.info("enter mobile no");
		
		details.enterAlias("abbkkk@gmail.com");
		logger.info("enter refrence email add"); 
		
		details.clkOnResister();
		logger.info("Clk on resister button");

		//Obj creation
		ResisterUserAccount account = new ResisterUserAccount(driver);
		String username = account.getUsername();
		logger.info("verify user account created or not");
		
		Assert.assertEquals("Sagu pran", username); // 1st expected and 2nd is actual
		logger.info("Check expected and actual result");
	}

}
