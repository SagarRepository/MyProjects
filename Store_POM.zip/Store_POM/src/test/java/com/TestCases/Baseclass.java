package com.TestCases;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.Utility.ReadConfig;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Baseclass {
	
	ReadConfig readconfig =  new ReadConfig();
	
	String url = readconfig.getBaseUrl();
	String browser = readconfig.getBrowser();
	
	public static WebDriver driver;
	public static Logger logger;
	
	@BeforeClass
	public void setUp()
	{
		
		switch (browser.toLowerCase()) 
		{
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
			
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;	
		
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;	

		default:
			driver = null;
			break;
		}
		
		// add 10 sec implicit wait applicable for all webelements 
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		// for adding logs
		 logger =  LogManager.getLogger("Store_POM"); // add project name in string
		 
	   // maximize
		 driver.manage().window().maximize();
		 
	}		
	
    //@AfterClass
	public void tearDown()
	{
		driver.close();
		driver.quit();
	}
	
	
	

}
