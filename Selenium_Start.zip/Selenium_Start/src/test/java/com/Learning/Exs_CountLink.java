package com.Learning;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Exs_CountLink {
	static WebDriver driver;
	@Test
	public static void link()
	{
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
		driver.get("https://www.calculator.net/");
		
		//stored in list
		List <WebElement> links = driver.findElements(By.tagName("a"));
		
		System.out.println("The total links are:"+ links.size());
		
		// print text of all anchor links
		for (WebElement el : links)
		{
			System.out.println(el.getText());
			System.out.println(el.getTagName());
			System.out.println(el.getClass());
			System.out.println(el.getLocation());
		}
		driver.close();
		
	}

}
