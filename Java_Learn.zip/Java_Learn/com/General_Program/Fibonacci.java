package com.General_Program;

public class Fibonacci {
	
	public static void main(String[] args) {
		
		//Fibonacci Series till 10 terms:0, 1, 1, 2, 3, 5, 8, 13, 21, 34,
		
		int a=0;
		int b=1;
		int num = 10;
		int c;
		
		for(int i=1; i<num; i++)
		{
			c = a+b;
			a=b;
			b=c;
			System.out.println("The fibonacci upto number ten is:"+c);
			
			
			
			/*
			 * c = a + b; (0 + 1) =1 a = b; (1) b = c; (1)
			 */
			  
			  
			 
		}
		
		
	}

}
