package com.String;

public class Reverse {
	
	public static void main(String[] args) {
		StringBuilder sb= new StringBuilder("Sagar");
		sb.reverse();
		System.out.println(sb); 
		
	}

}
