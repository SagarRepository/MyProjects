package com.String;



public class Palimdrome {

	public static void main(String[] args) {
	
		String str = "mom";
		String rev = "";
		
		for (int i=0; i<=str.length()-1; i++)    // 0<2 = mom, 1<2 = mom, 2<=2 = mom
		{
			System.out.print(str);
			
			
			rev = rev + str.charAt(i);
			System.out.println(i);
			System.out.println(str.length());
			
		}

	}

}
