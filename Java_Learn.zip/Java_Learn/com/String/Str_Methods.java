package com.String;

public class Str_Methods {
	
	public static void main(String[] args) {
		
		String str = " Welcome_to_TWJ";
		String a = "  abcdefxyz   ";
		String b = "new/life";
		
		// print char at index
		System.out.println(str.charAt(4));
		
		
		System.out.println(str.indexOf("e"));
		
		// print 3rd index to 6th index
		System.out.println(str.substring(3, 7));
		
		// if we pass only one value it will print rest of complete string
		System.out.println(str.substring(9));
		
		// concat string
		System.out.println(str.concat("In yavatmal"));
		
		// calculate length
		System.out.println(str.length());
		
		// remove spaces
		System.out.println(a.trim());
		
		// uppercase
		System.out.println(a.toUpperCase());
		
		// split
		System.out.println(b.split("/")); // returns a code we stored in array
		
		String [] arr = b.split("/");
		System.out.println(arr[0]);
		System.out.println(arr[1]);

		
		
	}
	

}
