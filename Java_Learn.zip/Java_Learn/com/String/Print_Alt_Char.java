package com.String;

public class Print_Alt_Char {
	
	public static void main(String[] args) {
		
		String str = "Jacobsons"; 
		for(int i = 0; i<=str.length() ; i=i+2)
		   System.out.print(str.charAt(i));
		
		//  0 1 2 3 4 5 6 7 8
		//  j a c o b s o n s
		// 0<9 =  0+2=2 print index 2
		// 2<9 =  2+2=4 print index 4
		// 4<9 =  4+2=6 print index 6
		// 6<9 =  6+2=8 print index 8
	}

}
