package com.BasicOperation;

public class PrintDemo {
	
	public static void main(String[] args) {
		
	
		
		
		
	}

}
