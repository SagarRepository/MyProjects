import org.testng.annotations.Test;

public class Testing_TestNG {
	
	@Test
	public static void  name() {
		System.out.println("Hello");
		
	}

}
