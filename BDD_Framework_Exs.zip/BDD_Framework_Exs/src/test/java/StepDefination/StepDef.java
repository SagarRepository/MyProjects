package StepDefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObject.LoginPage;
import dev.failsafe.internal.util.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

//import io.cucumber.java.en.* - If we add * then all file is import automatically

public class StepDef {

	public WebDriver driver;

	public LoginPage loginPg;

	@Given("User launch chrome browser")
	public void user_launch_chrome_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(); // initialize driver

		loginPg = new LoginPage(driver);

	}

	@When("User opens URL {string}")
	public void user_opens_url(String url)
	{
          driver.get(url);
	}

	@When("User enters email as {string} and password as {string}")
	public void user_enters_email_as_and_password_as(String emailAdd, String pwd) 
	{
        loginPg.enterEmail(emailAdd);
        loginPg.enterpwd(pwd);
	}

	@When("Click on login")
	public void click_on_login() 
	{
           loginPg.clkLogin();
	}

	@Then("Page title should be {string}")
	public void page_title_should_be(String expectedTitle) 
	{
        String actualTitle = driver.getTitle();
        if(actualTitle.equals(expectedTitle))
        {
          org.junit.Assert.assertTrue(true); // pass
        }
        else
        {
        	org.junit.Assert.assertTrue(false);
        }
	}

	@When("User click on Logout link")
	public void user_click_on_logout_link()
	{
       loginPg.clkLogOut();
	}

	@Then("Your page title should be {string}")
	public void your_page_title_should_be(String string)
	{

	}

	@Then("close browser")
	public void close_browser() 
	{
          driver.close();
          driver.quit();
	}

}
