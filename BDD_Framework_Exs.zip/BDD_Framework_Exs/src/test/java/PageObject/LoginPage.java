package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	// create object of webdriver
	WebDriver ldriver;
	
    // create constructor
	public LoginPage(WebDriver rDriver) // one parameter rDriver
	{
		ldriver = rDriver; // assign local driver to rDriver
		PageFactory.initElements(rDriver, this);			
	}
	
	@FindBy(xpath = "//input[@class ='email valid']")
	WebElement email;
	
	@FindBy(id = "Password")
	WebElement password;
	
	@FindBy(xpath = "//button[contains(text(),'Log in')]")
    WebElement loginBtn;
	
	@FindBy(xpath = "//a[contains(text(),'Logout')]")
	WebElement logout;
	
	
	// Create action method
	public void enterEmail(String emailAdd)
	{
		email.clear();
		email.sendKeys(emailAdd);
	}
	
	public void enterpwd(String pwd)
	{
		password.clear();
		password.sendKeys(pwd);
	}
	
	public void clkLogin()
	{
		loginBtn.click();
	}
	
	public void clkLogOut()
	{
		logout.click();
	}
 
}
